// Talking to the backend. Every request in the app goes through api().

const TOKEN_KEY = "khabo_token";

// localStorage keeps the login token after the page is closed.
// It can throw (private mode, blocked storage), so every use is wrapped.
export function getToken() {
  try {
    return localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setToken(token) {
  try {
    if (token) localStorage.setItem(TOKEN_KEY, token);
    else localStorage.removeItem(TOKEN_KEY);
  } catch {
    // Without storage the user stays logged in until the page reloads.
  }
}

// An error with the HTTP status code, so pages can react to 409, 403, ...
export class ApiError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

// Turn FastAPI's error body into one readable sentence.
function errorMessage(data, status) {
  const detail = data && data.detail;
  if (typeof detail === "string") return detail;
  if (Array.isArray(detail)) {
    // 422: a list like [{loc: ["body", "phone"], msg: "..."}]
    return detail.map((e) => `${e.loc[e.loc.length - 1]}: ${e.msg}`).join("; ");
  }
  return `Something went wrong (error ${status})`;
}

/**
 * Call the API.
 *   api("/restaurants")                                  GET
 *   api("/orders", { method: "POST", body: {...} })      JSON body
 *   api("/auth/login", { method: "POST", form: {...} })  form body (login only)
 * Returns the JSON answer, or throws ApiError.
 */
export async function api(path, { method = "GET", body, form } = {}) {
  const headers = {};
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;

  let payload;
  if (form) {
    payload = new URLSearchParams(form);
  } else if (body !== undefined) {
    headers["Content-Type"] = "application/json";
    payload = JSON.stringify(body);
  }

  let response;
  try {
    response = await fetch(`/api/v1${path}`, { method, headers, body: payload });
  } catch {
    throw new ApiError(0, "Cannot reach the server. Is it running?");
  }

  if (response.status === 401 && token) {
    // The token expired (60 minutes). Forget it and tell the app.
    setToken(null);
    window.dispatchEvent(new Event("auth-expired"));
  }
  if (response.status === 204) return null;

  const data = await response.json().catch(() => null);
  if (!response.ok) throw new ApiError(response.status, errorMessage(data, response.status));
  return data;
}
