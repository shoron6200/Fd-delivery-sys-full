# Demo Guide: presentation e ki dekhabe

Puro golpo ta website diye 8-10 minute e dekhano jay. Ager din **ontoto dui bar** practice koro.

## Age theke prostuti (5 minute)

```bash
# 1. Purono database muche notun demo data
#    (Windows e: del food_delivery.db)
rm -f food_delivery.db
python -m scripts.seed_demo

# 2. Server
uvicorn app.main:app
```

`seed_demo` 4 ta account ar 3 ta restaurant banay. Shob account er password: `demo-pass-123`. Login page e role er button chap dilei phone ar password nije boshe.

**4 ta login ek shathe:** ek browser window te ek ta login i thake. Tai:

| Window | Role |
|---|---|
| Chrome, normal | Customer |
| Chrome, Incognito (Ctrl+Shift+N) | Vendor |
| Edge (ba Firefox), normal | Rider |
| Edge, InPrivate (Ctrl+Shift+N) | Admin |

Shob gulo te **http://127.0.0.1:8000** khule login kore rakho. Screen e duita window pasha-pashi rakhle (customer + vendor) live update dekhano shohoj.

Arekta terminal khule rakho (project folder e, venv chalu), dhap 5 er jonno.

## Golpo

### 1. Shomossa ta bolo (30 second)

"Food app e 3 ta biroktikor jinish: checkout e dam bere jay, khabar late ashe kintu khotipuron pete jhamela, ar ki khabo thik korte shomoy jay. Amar project ei 3 ta shomadhan kore."

Home page er boro lekha ta dekhao: "Real menu prices. Late? We pay you."

### 2. Honest Price (Customer)

1. **Kacchi Ghor** e click
2. Kacchi Biryani **Add**, tarpor **+** (2 ta). Borhani **Add**
3. Nicher kalo bar e "3 items · total ৳745". **View cart**

Cart e "Honest Price" table dekhao: `৳700 + ৳40 + ৳5 = ৳745`.

**Bolo:** "Prothom item dewar shathe shathei puro hishab. Food er dam restaurant er nijer menu r dam. Kono lukano charge nai."

4. Address dao, **Place order**

**Bolo:** "Order eo ৳745. Cart ar order ek e function diye hishab kore, tai alada howa shombhob na." Order page er "We promised it by ..." lekha ta dekhao.

### 3. Restaurant (Vendor window)

Order ta nije theke chole ashe (8 second er moddhe). **Accept** chapo.

**Customer window e** kichu na chepe dekhao: dhap ta "Cooking" e chole geche.

**Bolo:** "Customer er page nije update hoy. Ar ekhon ar cancel kora jay na: order er dhap gula ekta state machine."

### 4. Rider (Rider window)

1. "Waiting for a rider" e order ta. **Take this delivery**
2. Delivery card e "Collect in cash: ৳745" dekhao

**Vendor window:** **Food is ready**

### 5. Late Compensation (terminal + Rider)

**Bolo:** "Ekhon dhori rider 35 minute late. 35 minute boshe na theke ekta demo script diye promise er shomoy pichiye dicchi."

```bash
python -m scripts.make_order_late 1 35
```

**Rider window:** page reload, **I picked up the food**, tarpor **Delivered to customer**.

**Customer window:** kichukkhon por nije theke sobuj lekha: "Arrived 35 minutes late. Sorry! ৳110 was added to your wallet."

**Bolo:** "Customer kichu koreni. Kono complain na, kono chat na. 30 minute er beshi late, tai delivery fee ৳40 ar khabar er 10% ৳70, mot ৳110 nije theke wallet e."

**Wallet** e click: ৳110, karon lekha.

### 6. Review (Customer)

Order page e 4 ta star, comment "Moja, kintu late", **Send review**. Form ta chole jay, abar deya jay na.

Kacchi Ghor er page e giye review ta ar rating ★ 4.0 dekhao.

**Bolo:** "Shudhu je khabar peyeche shei review dite pare, ek bar. Fake review deya jay na."

### 7. Recommendation (Customer)

Home e **Tomar jonno**: upore biryani, niche "You ordered this before", "Because you like Biryani".

**Bolo:** "Karon shoho dekhay. Eta rule-based, machine learning na, karon notun app e ML er moto data thake na."

### 8. Wallet diye order (Customer)

Burger Lab theke ekta Beef Burger, cart e **Pay with wallet credit** tick, order. Order page e "Paid from wallet − ৳110", "Cash to the rider ৳185".

### 9. AI Assistant (Customer, jodi API key thake)

Home er **Ki khete chao?** box e: `200 takar moddhe halka nasta ar cha, 2 jon` → **Ask** → **Add all to cart**.

**Bolo:** "Banglish bujhche. Model shudhu item er id bachhe, naam ar dam amar database theke ashe, tai model bhul dam bolte pare na."

Key na thakle lal notification ashbe. **Bolo:** "Bairer service na thakleo baki app chole."

### 10. Admin (Admin window, 30 second)

1. Restaurant list ar **Approve** button
2. Order table: kon order e koto compensation

Chaile vendor window e notun restaurant banao ("Waiting for admin"), admin e approve koro, customer er home e chole ashe.

### 11. Nirapotta (30 second)

Customer window e address bar e `#/admin` likho. Nijer page e fire ashe.

**Bolo:** "Frontend e o atkano, kintu ashol pahara backend e: API nijei 403 dey. Swagger e /docs e giye dekhano jay."

### 12. Test (terminal, 20 second)

```bash
python -m pytest -q
```

**Bolo:** "157 ta automatic test. Notun kichu jog korle bojha jay purono kichu bhangeni."

## Jodi kichu bhul hoy

| Shomossa | Shomadhan |
|---|---|
| "Your login expired" | Token er meyad shesh (60 minute). Abar login |
| Shob elomelo | `rm -f food_delivery.db`, `python -m scripts.seed_demo`, server restart, 4 window e abar login |
| `make_order_late` bole "already delivered" | Deliver korar **age** chalate hobe |
| "Take this delivery" bondho | Rider er hate onno delivery ache, age sheta shesh koro |
| Order nije ashche na | 8 second opekkha koro, ba page reload |
| Internet nai | Font ektu alada dekhabe, AI helper cholbe na. Baki shob chole |
| Website khule na, kintu `/docs` khule | `frontend` folder ta project er bhitore ache kina dekho |

## Shombhabbo proshno

Protita lesson er sheshe "Viva proshno" ache. Shobcheye beshi asha gula:

1. Password kivabe rakho? (Lesson 3)
2. JWT ki? Payload ki gopon? (Lesson 3)
3. `401` ar `403` er parthokko? (Lesson 4)
4. Taka `float` e rakho ni keno? (Lesson 4)
5. Cart e dam save koro na, order e koro, keno? (Lesson 5, 6)
6. Transaction / ACID ki? (Lesson 6)
7. Race condition ki? Ekta udahoron dao (Lesson 6, 7)
8. Wallet e balance column nai keno? (Lesson 9)
9. Tomar recommendation ki AI? (Lesson 10: shot uttor dao)
10. LLM bhul bolle ki hoy? (Lesson 11)
11. XSS ki? Tomar frontend e kivabe atkano? (Lesson 12)
12. Frontend e check thakleo backend e keno? (Lesson 12, 13)
13. Status nije update hoy kivabe? (Lesson 13: polling)

Shimabaddhota r talika `docs/project-report.md` er section 11 te. Nije theke bolle bhalo dekhay.
