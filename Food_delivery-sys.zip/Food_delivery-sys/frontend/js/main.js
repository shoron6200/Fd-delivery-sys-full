// The app's starting point: who is logged in, the top menu, and the router.

import { api, getToken, setToken } from "./api.js";
import { el, mount, toast } from "./ui.js";
import * as auth from "./pages/auth.js";
import * as customer from "./pages/customer.js";
import * as vendor from "./pages/vendor.js";
import * as rider from "./pages/rider.js";
import * as admin from "./pages/admin.js";

// Everything the pages share. One object, passed to every page as `ctx`.
const ctx = {
  user: null, // the logged-in user from /auth/me, or null
  cart: null, // the customer's cart from /cart, or null
  go, // go("#/cart") moves to another page
  refreshUser,
  refreshCart,
  every, // every(8000, fn): repeat fn while this page is open
  renderNav,
};

// Each route: a pattern for the part after "#", the page, and who may see it.
// null in `roles` means anyone, even without logging in.
const ROUTES = [
  { path: /^\/login$/, page: auth.loginPage, roles: null },
  { path: /^\/register$/, page: auth.registerPage, roles: null },
  { path: /^\/$/, page: homePage, roles: null },
  { path: /^\/restaurant\/(\d+)$/, page: customer.restaurantPage, roles: null },
  { path: /^\/cart$/, page: customer.cartPage, roles: ["customer"] },
  { path: /^\/orders$/, page: customer.ordersPage, roles: ["customer"] },
  { path: /^\/orders\/(\d+)$/, page: customer.orderPage, roles: ["customer"] },
  { path: /^\/wallet$/, page: customer.walletPage, roles: ["customer"] },
  { path: /^\/vendor$/, page: vendor.vendorPage, roles: ["vendor"] },
  { path: /^\/vendor\/restaurant\/(\d+)$/, page: vendor.restaurantAdminPage, roles: ["vendor"] },
  { path: /^\/rider$/, page: rider.riderPage, roles: ["rider"] },
  { path: /^\/admin$/, page: admin.adminPage, roles: ["admin"] },
];

// Each role has its own starting page.
const HOME_BY_ROLE = { vendor: "#/vendor", rider: "#/rider", admin: "#/admin" };

function homePage(params, context) {
  const home = context.user && HOME_BY_ROLE[context.user.role];
  if (home) {
    go(home);
    return null;
  }
  return customer.homePage(params, context);
}

function go(hash) {
  if (location.hash === hash) render();
  else location.hash = hash;
}

async function refreshUser() {
  ctx.user = null;
  if (getToken()) {
    try {
      ctx.user = await api("/auth/me");
    } catch {
      setToken(null);
    }
  }
  await refreshCart();
}

async function refreshCart() {
  ctx.cart = null;
  if (ctx.user && ctx.user.role === "customer") {
    try {
      ctx.cart = await api("/cart");
    } catch {
      // The menu still works; the cart badge just stays empty.
    }
  }
  renderNav();
}

function renderNav() {
  const nav = document.getElementById("nav");
  const links = [];
  const user = ctx.user;
  const link = (hash, text, extra) =>
    el("a", { href: hash, class: location.hash === hash ? "active" : null }, text, extra);

  if (!user) {
    links.push(link("#/", "Restaurants"), link("#/login", "Log in"));
  } else {
    if (user.role === "customer") {
      const count = ctx.cart ? ctx.cart.items.reduce((sum, line) => sum + line.quantity, 0) : 0;
      links.push(
        link("#/", "Restaurants"),
        link("#/orders", "Orders"),
        link("#/wallet", "Wallet"),
        link("#/cart", "Cart", count ? el("span", { class: "badge" }, count) : null),
      );
    } else {
      links.push(link(HOME_BY_ROLE[user.role], "Dashboard"));
    }
    links.push(
      el("span", { class: "who" }, `${user.name.split(" ")[0]} · ${user.role}`),
      el("button", { class: "btn btn-ghost btn-sm", onclick: logout }, "Log out"),
    );
  }
  mount(nav, links);
}

function logout() {
  setToken(null);
  ctx.user = null;
  ctx.cart = null;
  renderNav();
  go("#/");
  toast("Logged out");
}

// ---------- Router ----------

let timers = [];
let renderCount = 0;

function every(ms, fn) {
  const id = setInterval(fn, ms);
  timers.push(id);
  return id; // clearInterval(id) stops it early
}

async function render() {
  timers.forEach(clearInterval);
  timers = [];
  const myRender = ++renderCount;
  const root = document.getElementById("app");
  const path = location.hash.replace(/^#/, "") || "/";

  const route = ROUTES.find((r) => r.path.test(path));
  if (!route) {
    mount(root, el("div", { class: "empty" }, el("p", {}, "Page not found."), el("a", { href: "#/" }, "Go home")));
    return;
  }
  if (route.roles && (!ctx.user || !route.roles.includes(ctx.user.role))) {
    if (!ctx.user) {
      toast("Please log in first");
      go("#/login");
    } else {
      go(HOME_BY_ROLE[ctx.user.role] || "#/");
    }
    return;
  }

  renderNav();
  mount(root, el("div", { class: "loading" }, "Loading…"));
  const params = path.match(route.path).slice(1);
  try {
    const content = await route.page(params, ctx);
    // If the user clicked somewhere else while this page was loading, drop it.
    if (myRender === renderCount && content) {
      mount(root, content);
      root.focus({ preventScroll: true });
      window.scrollTo(0, 0);
    }
  } catch (error) {
    if (myRender === renderCount) {
      mount(root, el("div", { class: "empty" }, el("p", {}, error.message), el("a", { href: "#/" }, "Go home")));
    }
  }
}

window.addEventListener("hashchange", render);
window.addEventListener("auth-expired", () => {
  ctx.user = null;
  ctx.cart = null;
  toast("Your login expired. Please log in again.", "error");
  go("#/login");
});

await refreshUser();
render();
