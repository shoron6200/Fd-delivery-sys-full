// Log in and register pages.

import { api, setToken } from "../api.js";
import { busy, el, field, formData, pageTitle, toast } from "../ui.js";

// The accounts made by `python -m scripts.seed_demo`.
const DEMO_ACCOUNTS = [
  ["Customer", "01700000003"],
  ["Vendor", "01700000002"],
  ["Rider", "01700000004"],
  ["Admin", "01700000001"],
];
const DEMO_PASSWORD = "demo-pass-123";

async function logIn(phone, password, ctx) {
  // OAuth2 login form: the phone goes in the "username" field.
  const answer = await api("/auth/login", { method: "POST", form: { username: phone, password } });
  setToken(answer.access_token);
  await ctx.refreshUser();
  toast(`Welcome, ${ctx.user.name.split(" ")[0]}!`);
  ctx.go("#/");
}

export function loginPage(params, ctx) {
  const phone = el("input", { name: "phone", type: "tel", inputmode: "numeric", autocomplete: "username", required: true, placeholder: "01XXXXXXXXX" });
  const password = el("input", { name: "password", type: "password", autocomplete: "current-password", required: true });
  const submit = el("button", { class: "btn btn-primary btn-block", type: "submit" }, "Log in");

  const form = el(
    "form",
    {
      class: "card form",
      onsubmit: (event) => {
        event.preventDefault();
        const data = formData(form);
        busy(submit, () => logIn(data.phone, data.password, ctx));
      },
    },
    field("Phone number", phone),
    field("Password", password),
    submit,
    el("p", { class: "muted center" }, "No account? ", el("a", { href: "#/register" }, "Register")),
  );

  const demo = el(
    "div",
    { class: "card demo" },
    el("h2", { class: "h3" }, "Demo accounts"),
    el("p", { class: "muted small" }, "Made by python -m scripts.seed_demo. Click one to fill the form."),
    el(
      "div",
      { class: "demo-buttons" },
      DEMO_ACCOUNTS.map(([role, number]) =>
        el(
          "button",
          {
            class: "btn btn-ghost btn-sm",
            type: "button",
            onclick: () => {
              phone.value = number;
              password.value = DEMO_PASSWORD;
              submit.focus();
            },
          },
          role,
        ),
      ),
    ),
  );

  return el("div", { class: "auth" }, pageTitle("Log in"), form, demo);
}

export function registerPage(params, ctx) {
  const submit = el("button", { class: "btn btn-primary btn-block", type: "submit" }, "Create account");
  const form = el(
    "form",
    {
      class: "card form",
      onsubmit: (event) => {
        event.preventDefault();
        const data = formData(form);
        busy(submit, async () => {
          await api("/auth/register", { method: "POST", body: data });
          await logIn(data.phone, data.password, ctx);
        });
      },
    },
    field("Your name", el("input", { name: "name", required: true, minlength: 2, autocomplete: "name" })),
    field(
      "Phone number",
      el("input", { name: "phone", type: "tel", inputmode: "numeric", required: true, pattern: "01[3-9][0-9]{8}", placeholder: "01XXXXXXXXX", autocomplete: "username" }),
      "11 digits, starting with 013 to 019",
    ),
    field("Password", el("input", { name: "password", type: "password", required: true, minlength: 8, autocomplete: "new-password" }), "At least 8 characters"),
    field(
      "I am a",
      el(
        "select",
        { name: "role" },
        el("option", { value: "customer" }, "Customer (order food)"),
        el("option", { value: "vendor" }, "Restaurant owner"),
        el("option", { value: "rider" }, "Delivery rider"),
      ),
    ),
    submit,
    el("p", { class: "muted center" }, "Already registered? ", el("a", { href: "#/login" }, "Log in")),
  );
  return el("div", { class: "auth" }, pageTitle("Create an account"), form);
}
