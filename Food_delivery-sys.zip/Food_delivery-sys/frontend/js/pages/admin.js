// Admin page: approve restaurants and watch every order.

import { api } from "../api.js";
import { busy, dateTime, el, emptyState, money, mount, pageTitle, statusChip } from "../ui.js";

export async function adminPage(params, ctx) {
  const box = el("div", {});

  const load = async () => {
    const [restaurants, orders] = await Promise.all([api("/admin/restaurants"), api("/orders?limit=30")]);
    const waiting = restaurants.filter((r) => !r.is_approved);

    const approvalButton = (r) =>
      el(
        "button",
        {
          class: `btn btn-sm ${r.is_approved ? "btn-danger" : "btn-primary"}`,
          onclick: (event) =>
            (!r.is_approved || confirm(`Take ${r.name} off the platform?`)) &&
            busy(event.currentTarget, async () => {
              await api(`/admin/restaurants/${r.id}`, { method: "PATCH", body: { is_approved: !r.is_approved } });
              load();
            }),
        },
        r.is_approved ? "Remove approval" : "Approve",
      );

    mount(
      box,
      pageTitle("Admin"),
      el(
        "div",
        { class: "stats" },
        el("div", { class: "card stat" }, el("span", { class: "muted small" }, "Restaurants"), el("strong", {}, restaurants.length)),
        el("div", { class: "card stat" }, el("span", { class: "muted small" }, "Waiting approval"), el("strong", {}, waiting.length)),
        el("div", { class: "card stat" }, el("span", { class: "muted small" }, "Recent orders"), el("strong", {}, orders.length)),
      ),
      el(
        "section",
        { class: "section" },
        el("h2", { class: "h3" }, "Restaurants"),
        restaurants.length
          ? el(
              "ul",
              { class: "card lines" },
              restaurants.map((r) =>
                el(
                  "li",
                  {},
                  el("div", {}, el("div", {}, r.name), el("div", { class: "muted small" }, r.address)),
                  el(
                    "div",
                    { class: "line-end" },
                    r.is_approved ? el("span", { class: "chip chip-good" }, "Approved") : el("span", { class: "chip chip-warn" }, "Waiting"),
                    approvalButton(r),
                  ),
                ),
              ),
            )
          : emptyState("No restaurants yet."),
      ),
      el(
        "section",
        { class: "section" },
        el("h2", { class: "h3" }, "Latest orders"),
        orders.length
          ? el(
              "div",
              { class: "card table-wrap" },
              el(
                "table",
                {},
                el("thead", {}, el("tr", {}, ["#", "Restaurant", "Time", "Total", "Late comp.", "Status"].map((h) => el("th", {}, h)))),
                el(
                  "tbody",
                  {},
                  orders.map((o) =>
                    el(
                      "tr",
                      {},
                      el("td", {}, o.id),
                      el("td", {}, o.restaurant.name),
                      el("td", {}, dateTime(o.created_at)),
                      el("td", {}, money(o.price.total)),
                      el("td", {}, o.compensation ? money(o.compensation) : "–"),
                      el("td", {}, statusChip(o.status)),
                    ),
                  ),
                ),
              ),
            )
          : emptyState("No orders yet."),
      ),
    );
  };

  await load();
  return box;
}
