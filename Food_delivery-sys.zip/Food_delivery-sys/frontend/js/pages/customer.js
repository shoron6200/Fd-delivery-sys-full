// Customer pages: restaurants, menu, cart, orders, wallet, AI help.

import { api, ApiError } from "../api.js";
import {
  busy,
  clock,
  dateTime,
  el,
  emptyState,
  field,
  money,
  mount,
  pageTitle,
  remember,
  STATUS,
  stars,
  statusChip,
  toast,
} from "../ui.js";

// ---------- Cart actions (used on several pages) ----------

function quantityInCart(ctx, menuItemId) {
  const line = ctx.cart && ctx.cart.items.find((l) => l.menu_item_id === menuItemId);
  return line ? line.quantity : 0;
}

/**
 * Set how many of an item are in the cart (0 removes it). If the cart holds
 * another restaurant's food, ask before emptying it.
 */
async function setQuantity(ctx, menuItemId, quantity) {
  if (!ctx.user) {
    toast("Log in to order");
    ctx.go("#/login");
    return false;
  }
  if (ctx.user.role !== "customer") {
    toast("Only customer accounts can order", "error");
    return false;
  }
  try {
    if (quantity <= 0) {
      ctx.cart = await api(`/cart/items/${menuItemId}`, { method: "DELETE" });
    } else {
      ctx.cart = await api(`/cart/items/${menuItemId}`, { method: "PUT", body: { quantity } });
    }
  } catch (error) {
    const otherRestaurant = error instanceof ApiError && error.status === 409 && error.message.includes("another restaurant");
    if (!otherRestaurant) throw error;
    if (!confirm("Your cart has food from another restaurant. Empty the cart and add this instead?")) return false;
    await api("/cart", { method: "DELETE" });
    ctx.cart = await api(`/cart/items/${menuItemId}`, { method: "PUT", body: { quantity } });
  }
  ctx.renderNav();
  return true;
}

// A "− 2 +" control, or an "Add" button when the item is not in the cart.
function quantityControl(ctx, item, onChange) {
  const box = el("div", { class: "qty" });
  const draw = () => {
    const quantity = quantityInCart(ctx, item.id);
    const change = (to) => (event) =>
      busy(event.currentTarget, async () => {
        if (await setQuantity(ctx, item.id, to)) {
          draw();
          if (onChange) onChange();
        }
      });
    if (quantity === 0) {
      mount(box, el("button", { class: "btn btn-primary btn-sm", onclick: change(1), "aria-label": `Add ${item.name}` }, "Add"));
    } else {
      mount(
        box,
        el("button", { class: "btn btn-ghost btn-icon", onclick: change(quantity - 1), "aria-label": "One less" }, "−"),
        el("span", { class: "qty-n", "aria-live": "polite" }, quantity),
        el("button", { class: "btn btn-ghost btn-icon", onclick: change(quantity + 1), disabled: quantity >= 20, "aria-label": "One more" }, "+"),
      );
    }
  };
  draw();
  return box;
}

// ---------- Home ----------

function restaurantCard(restaurant) {
  return el(
    "a",
    { class: "card restaurant-card", href: `#/restaurant/${restaurant.id}` },
    el("div", { class: "rc-top" }, el("h3", {}, restaurant.name), el("span", { class: "rating" }, stars(restaurant.average_rating))),
    el("p", { class: "muted" }, restaurant.description || restaurant.address),
    el(
      "div",
      { class: "rc-meta" },
      restaurant.is_open ? el("span", { class: "chip chip-good" }, "Open") : el("span", { class: "chip chip-bad" }, "Closed"),
      el("span", { class: "muted small" }, `~${restaurant.avg_prep_minutes + 20} min`),
      restaurant.review_count ? el("span", { class: "muted small" }, `${restaurant.review_count} review${restaurant.review_count > 1 ? "s" : ""}`) : null,
    ),
  );
}

function assistantBox(ctx) {
  const results = el("div", { class: "assistant-results" });
  const input = el("input", {
    name: "message",
    required: true,
    minlength: 2,
    maxlength: 500,
    placeholder: "e.g. 500 takar moddhe 2 jon er jonno jhal kichu",
    "aria-label": "What do you feel like eating?",
  });
  const button = el("button", { class: "btn btn-primary", type: "submit" }, "Ask");

  const showAnswer = (answer) => {
    if (!answer.suggestions.length) {
      mount(results, el("p", { class: "assistant-reply" }, answer.reply));
      return;
    }
    const addAll = el("button", { class: "btn btn-primary btn-sm" }, `Add all to cart · ${money(answer.food_total)}`);
    addAll.addEventListener("click", () =>
      busy(addAll, async () => {
        for (const suggestion of answer.suggestions) {
          const added = await setQuantity(ctx, suggestion.item.id, suggestion.quantity);
          if (!added) return;
        }
        toast("Added to cart");
        ctx.go("#/cart");
      }),
    );
    mount(
      results,
      el("p", { class: "assistant-reply" }, answer.reply),
      el(
        "ul",
        { class: "lines" },
        answer.suggestions.map((s) =>
          el(
            "li",
            {},
            el("span", {}, `${s.quantity} × ${s.item.name}`, el("span", { class: "muted small" }, ` · ${s.item.restaurant.name}`)),
            el("span", { class: "price" }, money(s.line_total)),
          ),
        ),
      ),
      el("div", { class: "row-end" }, el("span", { class: "muted small" }, "Food only. Fees are shown in the cart."), addAll),
    );
  };

  return el(
    "section",
    { class: "card assistant" },
    el("h2", { class: "h3" }, "Ki khete chao?"),
    el("p", { class: "muted small" }, "Tell the AI helper in Bangla, English or Banglish. It only picks from food you can order right now."),
    el(
      "form",
      {
        class: "assistant-form",
        onsubmit: (event) => {
          event.preventDefault();
          busy(button, async () => {
            mount(results, el("p", { class: "muted" }, "Thinking…"));
            try {
              showAnswer(await api("/assistant/suggest", { method: "POST", body: { message: input.value } }));
            } catch (error) {
              mount(results);
              throw error;
            }
          });
        },
      },
      input,
      button,
    ),
    results,
  );
}

function recommendationStrip(ctx, recommendations) {
  if (!recommendations.length) return null;
  return el(
    "section",
    { class: "section" },
    el("h2", { class: "h3" }, "Tomar jonno"),
    el(
      "div",
      { class: "strip" },
      recommendations.map((r) =>
        el(
          "div",
          { class: "card rec" },
          el("div", { class: "rec-name" }, r.item.name),
          el("div", { class: "muted small" }, r.item.restaurant.name),
          el("div", { class: "rec-reason" }, r.reason),
          el("div", { class: "row-end" }, el("span", { class: "price" }, money(r.item.price)), quantityControl(ctx, r.item)),
        ),
      ),
    ),
  );
}

export async function homePage(params, ctx) {
  const isCustomer = ctx.user && ctx.user.role === "customer";
  const [restaurants, recommendations] = await Promise.all([
    api("/restaurants?limit=100"),
    isCustomer ? api("/recommendations?limit=8").catch(() => []) : [],
  ]);

  const grid = el("div", { class: "grid" });
  const drawGrid = (list) =>
    mount(grid, list.length ? list.map(restaurantCard) : emptyState("No restaurant matches that name."));
  drawGrid(restaurants);

  let searchTimer;
  const search = el("input", {
    type: "search",
    placeholder: "Search restaurants",
    "aria-label": "Search restaurants",
    oninput: (event) => {
      clearTimeout(searchTimer);
      const text = event.target.value.trim();
      // Wait until typing pauses, so we do not send a request per letter.
      searchTimer = setTimeout(async () => {
        const query = text ? `&search=${encodeURIComponent(text)}` : "";
        drawGrid(await api(`/restaurants?limit=100${query}`));
      }, 300);
    },
  });

  return el(
    "div",
    {},
    el(
      "section",
      { class: "hero" },
      el("h1", {}, "Real menu prices. Late? We pay you."),
      el("p", { class: "muted" }, "Every fee is shown before you order. If your food is more than 15 minutes late, credit lands in your wallet by itself."),
    ),
    isCustomer ? assistantBox(ctx) : null,
    isCustomer ? recommendationStrip(ctx, recommendations) : null,
    el("section", { class: "section" }, el("div", { class: "row-between list-head" }, el("h2", { class: "h3" }, "Restaurants"), search), grid),
  );
}

// ---------- One restaurant ----------

export async function restaurantPage([id], ctx) {
  const [restaurant, menu, reviews] = await Promise.all([
    api(`/restaurants/${id}`),
    api(`/restaurants/${id}/menu`),
    api(`/restaurants/${id}/reviews?limit=10`),
  ]);

  const cartBar = el("div", { class: "cart-bar" });
  const drawCartBar = () => {
    const cart = ctx.cart;
    if (!cart || !cart.items.length || !cart.restaurant || cart.restaurant.id !== restaurant.id) {
      mount(cartBar);
      return;
    }
    const count = cart.items.reduce((sum, line) => sum + line.quantity, 0);
    mount(
      cartBar,
      el("span", {}, `${count} item${count > 1 ? "s" : ""} · total ${money(cart.price.total)}`),
      el("a", { class: "btn btn-primary btn-sm", href: "#/cart" }, "View cart"),
    );
  };
  drawCartBar();

  // Group the menu by category, keeping the order the restaurant used.
  const groups = new Map();
  for (const item of menu) {
    if (!groups.has(item.category)) groups.set(item.category, []);
    groups.get(item.category).push(item);
  }

  const canOrder = restaurant.is_open && restaurant.is_approved;
  const menuSection = el(
    "section",
    { class: "section" },
    el("h2", { class: "h3" }, "Menu"),
    menu.length
      ? [...groups.entries()].map(([category, items]) =>
          el(
            "div",
            { class: "menu-group" },
            el("h3", { class: "menu-cat" }, category),
            items.map((item) =>
              el(
                "div",
                { class: `menu-item${item.is_available ? "" : " off"}` },
                el(
                  "div",
                  {},
                  el("div", { class: "mi-name" }, item.name),
                  item.description ? el("div", { class: "muted small" }, item.description) : null,
                  el("div", { class: "price" }, money(item.price)),
                ),
                !item.is_available
                  ? el("span", { class: "muted small" }, "Not available now")
                  : canOrder
                    ? quantityControl(ctx, item, drawCartBar)
                    : null,
              ),
            ),
          ),
        )
      : emptyState("This restaurant has no menu yet."),
  );

  return el(
    "div",
    {},
    el("a", { class: "back", href: "#/" }, "← All restaurants"),
    el(
      "section",
      { class: "card restaurant-head" },
      el("div", { class: "row-between" }, el("h1", {}, restaurant.name), el("span", { class: "rating big" }, stars(restaurant.average_rating))),
      restaurant.description ? el("p", {}, restaurant.description) : null,
      el("p", { class: "muted small" }, restaurant.address),
      el(
        "div",
        { class: "rc-meta" },
        restaurant.is_open ? el("span", { class: "chip chip-good" }, "Open") : el("span", { class: "chip chip-bad" }, "Closed now"),
        el("span", { class: "muted small" }, `Cooking ~${restaurant.avg_prep_minutes} min + delivery ~20 min`),
      ),
    ),
    menuSection,
    el(
      "section",
      { class: "section" },
      el("h2", { class: "h3" }, `Reviews (${restaurant.review_count})`),
      el("p", { class: "muted small" }, "Only customers who received an order can review it, once."),
      reviews.length
        ? el(
            "div",
            { class: "reviews" },
            reviews.map((r) =>
              el(
                "div",
                { class: "card review" },
                el("div", { class: "row-between" }, el("strong", {}, r.customer_name), el("span", { class: "rating" }, "★".repeat(r.rating))),
                r.comment ? el("p", {}, r.comment) : null,
                el("span", { class: "muted small" }, dateTime(r.created_at)),
              ),
            ),
          )
        : emptyState("No reviews yet."),
    ),
    cartBar,
  );
}

// ---------- Cart ----------

function priceTable(price, extraRows = []) {
  const row = (label, value, cls) => el("div", { class: `pt-row ${cls || ""}` }, el("span", {}, label), el("span", {}, value));
  return el(
    "div",
    { class: "price-table" },
    row("Food (menu prices)", money(price.subtotal)),
    row("Delivery fee", money(price.delivery_fee)),
    row("Platform fee", money(price.platform_fee)),
    row("Total", money(price.total), "pt-total"),
    extraRows.map(([label, value, cls]) => row(label, value, cls)),
  );
}

export async function cartPage(params, ctx) {
  await ctx.refreshCart();
  const wallet = await api("/wallet").catch(() => ({ balance: 0 }));
  const box = el("div", {});

  const draw = () => {
    const cart = ctx.cart;
    if (!cart || !cart.items.length) {
      mount(box, pageTitle("Your cart"), emptyState("Your cart is empty.", el("a", { class: "btn btn-primary", href: "#/" }, "Find food")));
      return;
    }
    const unavailable = cart.items.filter((line) => !line.is_available);
    const address = el("textarea", { name: "address", rows: 2, required: true, minlength: 5, maxlength: 255, placeholder: "Flat, house, road, area" });
    address.value = remember("khabo_address") || "";
    // Remember while typing, so a quantity change (which redraws) keeps it.
    address.addEventListener("input", () => remember("khabo_address", address.value));
    const useWallet = el("input", { type: "checkbox", name: "use_wallet", disabled: wallet.balance <= 0 });
    const placeButton = el("button", { class: "btn btn-primary btn-block", type: "submit", disabled: unavailable.length > 0 }, `Place order · ${money(cart.price.total)}`);

    const form = el(
      "form",
      {
        class: "card form",
        onsubmit: (event) => {
          event.preventDefault();
          busy(placeButton, async () => {
            remember("khabo_address", address.value);
            const order = await api("/orders", {
              method: "POST",
              body: { delivery_address: address.value, use_wallet: useWallet.checked },
            });
            await ctx.refreshCart();
            toast("Order placed!");
            ctx.go(`#/orders/${order.id}`);
          });
        },
      },
      field("Delivery address", address),
      el(
        "label",
        { class: "check" },
        useWallet,
        el("span", {}, `Pay with wallet credit (you have ${money(wallet.balance)})`),
      ),
      el("p", { class: "muted small" }, "The rest is paid in cash to the rider."),
      placeButton,
    );

    mount(
      box,
      pageTitle("Your cart", `From ${cart.restaurant.name}`),
      el(
        "div",
        { class: "two-col" },
        el(
          "div",
          { class: "card" },
          el(
            "ul",
            { class: "lines" },
            cart.items.map((line) =>
              el(
                "li",
                { class: line.is_available ? "" : "off" },
                el(
                  "div",
                  {},
                  el("div", {}, line.name),
                  el("div", { class: "muted small" }, `${money(line.unit_price)} each`),
                  line.is_available ? null : el("div", { class: "warn small" }, "Not available any more. Remove it to order."),
                ),
                el("div", { class: "line-end" }, quantityControl(ctx, { id: line.menu_item_id, name: line.name }, draw), el("span", { class: "price" }, money(line.line_total))),
              ),
            ),
          ),
          el("h2", { class: "h3" }, "Honest Price"),
          priceTable(cart.price),
          el("p", { class: "muted small" }, "This is exactly what you pay. Prices are the restaurant's own menu prices."),
        ),
        form,
      ),
    );
  };
  draw();
  return box;
}

// ---------- Orders ----------

export async function ordersPage(params, ctx) {
  const orders = await api("/orders?limit=50");
  return el(
    "div",
    {},
    pageTitle("Your orders"),
    orders.length
      ? el(
          "div",
          { class: "stack" },
          orders.map((order) =>
            el(
              "a",
              { class: "card order-row", href: `#/orders/${order.id}` },
              el("div", {}, el("strong", {}, `#${order.id} · ${order.restaurant.name}`), el("div", { class: "muted small" }, dateTime(order.created_at))),
              el("div", { class: "line-end" }, statusChip(order.status), el("span", { class: "price" }, money(order.price.total))),
            ),
          ),
        )
      : emptyState("No orders yet.", el("a", { class: "btn btn-primary", href: "#/" }, "Find food")),
  );
}

const STEPS = ["placed", "accepted", "ready", "picked_up", "delivered"];
const FINISHED = ["delivered", "rejected", "cancelled"];

function progress(status) {
  if (status === "rejected" || status === "cancelled") {
    return el("div", { class: "banner banner-bad" }, status === "rejected" ? "The restaurant could not take this order." : "You cancelled this order.");
  }
  const reached = STEPS.indexOf(status);
  return el(
    "ol",
    { class: "steps" },
    STEPS.map((step, i) => el("li", { class: i < reached ? "done" : i === reached ? "now" : "" }, STATUS[step].label)),
  );
}

function reviewForm(ctx, order, onDone) {
  let rating = 5;
  const starButtons = [1, 2, 3, 4, 5].map((n) =>
    el("button", { type: "button", class: "star", "aria-label": `${n} stars`, onclick: () => setRating(n) }, "★"),
  );
  const setRating = (n) => {
    rating = n;
    starButtons.forEach((b, i) => b.classList.toggle("on", i < n));
  };
  setRating(5);
  const comment = el("textarea", { rows: 2, maxlength: 500, placeholder: "How was the food? (optional)" });
  const send = el("button", { class: "btn btn-primary", type: "submit" }, "Send review");
  return el(
    "form",
    {
      class: "card form",
      onsubmit: (event) => {
        event.preventDefault();
        busy(send, async () => {
          await api(`/orders/${order.id}/review`, { method: "POST", body: { rating, comment: comment.value || null } });
          toast("Thanks for the review!");
          onDone();
        });
      },
    },
    el("h2", { class: "h3" }, "Rate this order"),
    el("div", { class: "stars", role: "group", "aria-label": "Rating" }, starButtons),
    comment,
    send,
  );
}

export async function orderPage([id], ctx) {
  const box = el("div", {});

  const draw = (order) => {
    const late = order.late_minutes;
    let lateNote = null;
    if (order.status === "delivered") {
      lateNote =
        order.compensation > 0
          ? el("div", { class: "banner banner-good" }, `Arrived ${late} minutes late. Sorry! ${money(order.compensation)} was added to your wallet.`)
          : el("div", { class: "banner banner-good" }, late > 0 ? `Delivered ${late} minutes after the promised time.` : "Delivered on time.");
    }

    const cancel =
      order.status === "placed"
        ? el(
            "button",
            {
              class: "btn btn-danger",
              onclick: (event) =>
                confirm("Cancel this order?") &&
                busy(event.currentTarget, async () => {
                  draw(await api(`/orders/${order.id}/status`, { method: "PATCH", body: { status: "cancelled" } }));
                  toast("Order cancelled");
                }),
            },
            "Cancel order",
          )
        : null;

    const extra = [];
    if (order.wallet_used) extra.push(["Paid from wallet", `− ${money(order.wallet_used)}`]);
    extra.push(["Cash to the rider", money(order.amount_due), "pt-total"]);

    mount(
      box,
      el("a", { class: "back", href: "#/orders" }, "← All orders"),
      pageTitle(`Order #${order.id}`, `${order.restaurant.name} · ${dateTime(order.created_at)}`),
      progress(order.status),
      FINISHED.includes(order.status)
        ? null
        : el("p", { class: "promise" }, "We promised it by ", el("strong", {}, clock(order.promised_at)), ". If it is more than 15 minutes late, you get wallet credit automatically."),
      lateNote,
      el(
        "div",
        { class: "two-col" },
        el(
          "div",
          { class: "card" },
          el(
            "ul",
            { class: "lines" },
            order.items.map((item) => el("li", {}, el("span", {}, `${item.quantity} × ${item.name}`), el("span", { class: "price" }, money(item.line_total)))),
          ),
          priceTable(order.price, extra),
          el("p", { class: "muted small" }, `Deliver to: ${order.delivery_address}`),
          cancel,
        ),
        order.status === "delivered" && !order.is_reviewed
          ? reviewForm(ctx, order, async () => draw(await api(`/orders/${order.id}`)))
          : null,
      ),
    );
    return FINISHED.includes(order.status);
  };

  const finished = draw(await api(`/orders/${id}`));
  if (!finished) {
    // Ask the server again every 8 seconds, so the status moves by itself.
    // Stop once the order is finished (and the review form may be in use).
    const timer = ctx.every(8000, async () => {
      try {
        if (draw(await api(`/orders/${id}`))) clearInterval(timer);
      } catch {
        // Try again next time.
      }
    });
  }
  return box;
}

// ---------- Wallet ----------

export async function walletPage(params, ctx) {
  const wallet = await api("/wallet");
  return el(
    "div",
    {},
    pageTitle("Wallet"),
    el(
      "section",
      { class: "card wallet-hero" },
      el("span", { class: "muted" }, "Balance"),
      el("div", { class: "wallet-balance" }, money(wallet.balance)),
      el("p", { class: "muted small" }, "Credit comes in by itself when an order is late. Use it at checkout."),
    ),
    el(
      "section",
      { class: "section" },
      el("h2", { class: "h3" }, "History"),
      wallet.transactions.length
        ? el(
            "ul",
            { class: "card lines" },
            wallet.transactions.map((t) =>
              el(
                "li",
                {},
                el("div", {}, el("div", {}, t.reason), el("div", { class: "muted small" }, dateTime(t.created_at))),
                el("span", { class: t.amount > 0 ? "plus" : "minus" }, `${t.amount > 0 ? "+" : "−"} ${money(Math.abs(t.amount))}`),
              ),
            ),
          )
        : emptyState("Nothing here yet."),
    ),
  );
}
