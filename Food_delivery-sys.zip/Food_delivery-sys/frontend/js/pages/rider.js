// Rider page: the current delivery and the orders waiting for a rider.

import { api } from "../api.js";
import { busy, clock, el, emptyState, money, mount, pageTitle, statusChip, toast } from "../ui.js";

const IN_HAND = ["accepted", "ready", "picked_up"];

function currentDelivery(order, reload) {
  const step = (status, label) =>
    el(
      "button",
      {
        class: "btn btn-primary btn-block",
        onclick: (event) =>
          busy(event.currentTarget, async () => {
            await api(`/orders/${order.id}/status`, { method: "PATCH", body: { status } });
            toast(status === "delivered" ? "Delivered. Well done!" : "Picked up");
            reload();
          }),
      },
      label,
    );

  let action;
  if (order.status === "picked_up") action = step("delivered", "Delivered to customer");
  else if (order.status === "ready") action = step("picked_up", "I picked up the food");
  else action = el("p", { class: "muted" }, "The restaurant is still cooking. Head there now.");

  return el(
    "div",
    { class: "card delivery" },
    el("div", { class: "row-between" }, el("h2", { class: "h3" }, `Order #${order.id}`), statusChip(order.status)),
    el("p", {}, el("strong", {}, "Pick up: "), order.restaurant.name),
    el("p", {}, el("strong", {}, "Deliver to: "), order.delivery_address),
    el("p", {}, el("strong", {}, "Promised by: "), clock(order.promised_at)),
    el("ul", { class: "lines compact" }, order.items.map((i) => el("li", {}, `${i.quantity} × ${i.name}`))),
    el("div", { class: "collect" }, "Collect in cash: ", el("strong", {}, money(order.amount_due))),
    action,
  );
}

export async function riderPage(params, ctx) {
  const box = el("div", {});

  const load = async () => {
    const [mine, available] = await Promise.all([api("/orders?limit=50"), api("/orders/available")]);
    const current = mine.find((o) => IN_HAND.includes(o.status));
    const deliveredCount = mine.filter((o) => o.status === "delivered").length;

    mount(
      box,
      pageTitle("Rider dashboard", `${deliveredCount} deliveries done`),
      el("section", { class: "section" }, el("h2", { class: "h3" }, "Your delivery"), current ? currentDelivery(current, load) : emptyState("You are free. Take an order below.")),
      el(
        "section",
        { class: "section" },
        el("h2", { class: "h3" }, "Waiting for a rider"),
        available.length
          ? el(
              "div",
              { class: "stack" },
              available.map((order) =>
                el(
                  "div",
                  { class: "card row-between wrap" },
                  el(
                    "div",
                    {},
                    el("strong", {}, `#${order.id} · ${order.restaurant.name}`),
                    el("div", { class: "muted small" }, `To: ${order.delivery_address}`),
                    el("div", { class: "muted small" }, `Promised by ${clock(order.promised_at)} · collect ${money(order.amount_due)}`),
                  ),
                  el(
                    "button",
                    {
                      class: "btn btn-primary btn-sm",
                      disabled: Boolean(current),
                      title: current ? "Finish your current delivery first" : null,
                      onclick: (event) =>
                        busy(event.currentTarget, async () => {
                          await api(`/orders/${order.id}/claim`, { method: "POST" });
                          toast(`Order #${order.id} is yours`);
                          load();
                        }),
                    },
                    "Take this delivery",
                  ),
                ),
              ),
            )
          : emptyState("No orders are waiting right now. This list updates by itself."),
      ),
    );
  };

  await load();
  ctx.every(8000, () => load().catch(() => {}));
  return box;
}
