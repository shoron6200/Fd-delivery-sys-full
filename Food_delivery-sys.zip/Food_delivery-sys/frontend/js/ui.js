// Small helpers for building the page. No framework: just the browser's DOM.

/**
 * Make an element:  el("button", { class: "btn", onclick: fn }, "Order koro")
 *
 * Text children become text nodes, never HTML. So a restaurant called
 * "<script>..." is shown as those letters and never runs. This is the
 * defence against XSS, and the reason this app never uses innerHTML.
 */
export function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(attrs)) {
    if (value === null || value === undefined || value === false) continue;
    if (key.startsWith("on")) node.addEventListener(key.slice(2), value);
    else if (key === "class") node.className = value;
    else if (key === "value") node.value = value;
    else if (value === true) node.setAttribute(key, "");
    else node.setAttribute(key, value);
  }
  for (const child of children.flat()) {
    if (child === null || child === undefined || child === false) continue;
    node.append(child instanceof Node ? child : String(child));
  }
  return node;
}

// Replace everything inside `parent`.
export function mount(parent, ...children) {
  parent.replaceChildren(...children.flat().filter(Boolean));
}

export function money(taka) {
  return `৳${Number(taka).toLocaleString("en-IN")}`;
}

// Server times are UTC ("...Z"). The browser shows them in local time.
export function clock(iso) {
  return new Date(iso).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
}

export function dateTime(iso) {
  return new Date(iso).toLocaleString([], {
    day: "numeric",
    month: "short",
    hour: "numeric",
    minute: "2-digit",
  });
}

export function stars(rating) {
  return rating === null || rating === undefined ? "New" : `★ ${rating.toFixed(1)}`;
}

export const STATUS = {
  placed: { label: "Order placed", tone: "info" },
  accepted: { label: "Cooking", tone: "info" },
  ready: { label: "Ready for pickup", tone: "info" },
  picked_up: { label: "On the way", tone: "info" },
  delivered: { label: "Delivered", tone: "good" },
  rejected: { label: "Rejected", tone: "bad" },
  cancelled: { label: "Cancelled", tone: "bad" },
};

export function statusChip(status) {
  const info = STATUS[status] || { label: status, tone: "info" };
  return el("span", { class: `chip chip-${info.tone}` }, info.label);
}

export function toast(message, kind = "ok") {
  const box = el("div", { class: `toast toast-${kind}`, role: kind === "error" ? "alert" : "status" }, message);
  document.getElementById("toasts").append(box);
  setTimeout(() => box.remove(), 4500);
}

/**
 * Run an async action from a button: disable the button while it runs and
 * show any error as a toast. Returns the action's result (or undefined).
 */
export async function busy(button, action) {
  if (button) button.disabled = true;
  try {
    return await action();
  } catch (error) {
    toast(error.message, "error");
    return undefined;
  } finally {
    if (button) button.disabled = false;
  }
}

export function emptyState(text, ...extra) {
  return el("div", { class: "empty" }, el("p", {}, text), ...extra);
}

export function pageTitle(text, sub) {
  return el("div", { class: "page-head" }, el("h1", {}, text), sub ? el("p", { class: "muted" }, sub) : null);
}

// Read a <form> into a plain object: { phone: "...", password: "..." }
export function formData(form) {
  return Object.fromEntries(new FormData(form).entries());
}

export function field(label, input, hint) {
  return el("label", { class: "field" }, el("span", { class: "field-label" }, label), input, hint ? el("span", { class: "field-hint" }, hint) : null);
}

export function remember(key, value) {
  try {
    if (value === undefined) return localStorage.getItem(key);
    localStorage.setItem(key, value);
  } catch {
    // Storage blocked: just do not remember.
  }
  return null;
}
