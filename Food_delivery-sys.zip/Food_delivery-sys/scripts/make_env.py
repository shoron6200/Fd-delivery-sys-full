"""Create the .env file with a fresh SECRET_KEY, or fill in a missing key.

Run from the project folder:  python -m scripts.make_env

Safe to run more than once: a key that is already set is never replaced,
because replacing it would log everyone out.
"""

import re
import secrets
import shutil
import sys
from pathlib import Path

# Plain file work only: importing app.core.config here would stop on the very
# missing key this script is meant to add.
ENV = Path(".env")
EXAMPLE = Path(".env.example")
KEY_LINE = re.compile(r"^SECRET_KEY=(.*)$", re.MULTILINE)


def main() -> int:
    if not ENV.exists():
        if not EXAMPLE.exists():
            print("Run this from the project folder (the one with .env.example).")
            return 1
        shutil.copy(EXAMPLE, ENV)
        print("Created .env from .env.example.")

    text = ENV.read_text(encoding="utf-8")
    match = KEY_LINE.search(text)
    if match and len(match.group(1).strip()) >= 32:
        print("SECRET_KEY is already set. Nothing to do.")
        return 0

    line = f"SECRET_KEY={secrets.token_hex(32)}"
    if match:
        text = text[: match.start()] + line + text[match.end() :]
    else:
        text = text.rstrip("\n") + "\n" + line + "\n"
    ENV.write_text(text, encoding="utf-8")
    print("SECRET_KEY added to .env. You can start the server now.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
