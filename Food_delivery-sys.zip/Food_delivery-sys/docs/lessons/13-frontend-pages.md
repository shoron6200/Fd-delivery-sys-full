# Lesson 13: Frontend er Page gula: Router, Cart, Live Status, Role Dashboard

Ei lesson er code: `frontend/js/main.js`, `frontend/js/pages/customer.js`, `frontend/js/pages/vendor.js`, `frontend/js/pages/rider.js`, `frontend/js/pages/admin.js`

## 1. Ki ki page ache

| Address | Page | Ke |
|---|---|---|
| `#/` | Restaurant, "Tomar jonno", AI helper | shobai (AI helper shudhu customer) |
| `#/restaurant/1` | Menu + review | shobai |
| `#/cart` | Cart, Honest Price, order kora | customer |
| `#/orders`, `#/orders/5` | Order list, ekta order er live obostha | customer |
| `#/wallet` | Balance + itihash | customer |
| `#/vendor` | Order accept/ready, restaurant | vendor |
| `#/vendor/restaurant/1` | Menu edit | vendor |
| `#/rider` | Current delivery, opekkhay thaka order | rider |
| `#/admin` | Approve, shob order | admin |
| `#/login`, `#/register` | | shobai |

## 2. Router: `#` er pore r ongsho

Address e `#` er porer ongsho (`#/cart`) bodlale browser **server e jay na**, shudhu `hashchange` event dey. Amra sheta shuni:

```js
window.addEventListener("hashchange", render);
```

`render` `ROUTES` talika theke milay:

```js
{ path: /^\/orders\/(\d+)$/, page: customer.orderPage, roles: ["customer"] },
```

- `path` ekta **regular expression**. `(\d+)` mane "ek ba beshi shonkha, eta dhore rakho". `#/orders/5` hole page pay `["5"]`
- `roles` mane ke dekhte parbe. Login nai? Login page e pathay. Bhul role? Nijer dashboard e

Python e FastAPI je kaj kore (`@router.get("/orders/{order_id}")`), browser e amra ei 20 line e nije korechi.

**Shabdhan:** frontend er `roles` check shudhu **shubidha**. Keu address e `#/admin` likhle page khulte cheshta korbe, kintu `/admin/restaurants` API `403` debe. Ashol pahara backend e (Lesson 4, 7). Lesson 12, section 8 er niyom tai.

Ar `renderCount` diye ekta choto shomossa thekano: tumi page A te click korle, sheta load howar majhe B te click korle, A der e ese B ke muche felte pare. Tai shudhu shesh click er page i boshano hoy.

## 3. `ctx`: page gular shared jinish

```js
const ctx = { user, cart, go, refreshUser, refreshCart, every, renderNav };
```

Protita page `ctx` pay: ke login kora (`ctx.user`), cart e ki (`ctx.cart`), onno page e jawa (`ctx.go("#/cart")`). Ek jaygay rakhle upore r cart badge ar page er cart shob shomoy ek thake.

## 4. Cart button: `− 2 +`

`quantityControl` ekta choto component: cart e na thakle "Add", thakle `− 2 +`.

Backend er `PUT /cart/items/{id}` quantity **set** kore (Lesson 5, section 7), tai `+` chaple pathai `quantity + 1`, `−` chaple `quantity - 1`, ar 0 hole `DELETE`.

Onno restaurant er khabar cart e thakle backend `409` dey. Frontend sheta dhore:

```js
const otherRestaurant = error instanceof ApiError && error.status === 409 && error.message.includes("another restaurant");
if (!confirm("Your cart has food from another restaurant. Empty the cart and add this instead?")) return false;
```

Backend er niyom (ek cart e ek restaurant) ekta bhalo prosno hoye user er shamne ashe. Error ke shundor kore dekhano frontend er kaj.

## 5. Honest Price page e

Cart page e `priceTable(cart.price)`:

```
Food (menu prices)   ৳700
Delivery fee          ৳40
Platform fee           ৳5
Total                ৳745
```

Frontend **kono hishab kore na**. Shob shonkha backend er `/cart` theke ashe. Hishab browser e korle duita jaygay hishab hoto, ar ekdin mile na (Lesson 5, section 2). Frontend er kaj shudhu **dekhano**.

## 6. Live order status: polling

Order page e status nije theke bodlay (Cooking → On the way → Delivered). Kivabe?

```js
const timer = ctx.every(8000, async () => {
  if (draw(await api(`/orders/${id}`))) clearInterval(timer);
});
```

Protita 8 second e server ke abar jiggesh kori. Eke bole **polling**. `draw` order shesh hole `true` dey, tokhon thami (na hole review lekhar shomoy form muche jeto).

Onno page e gele `main.js` shob timer bondho kore dey, jate pichone request cholte na thake.

| | Polling (amader) | WebSocket |
|---|---|---|
| Kivabe | client bar bar jiggesh kore | server nije khobor pathay |
| Shohoj? | khub | beshi kaj |
| Deri | 8 second porjonto | prae shathe shathe |
| Server e chap | beshi user hole beshi | kom |

Varsity project e polling jothesto. Boro app e WebSocket (PLAN.md er Phase 2).

## 7. Late Compensation page e

Order `delivered` hole:

```js
order.compensation > 0
  ? el("div", { class: "banner banner-good" }, `Arrived ${late} minutes late. Sorry! ${money(order.compensation)} was added to your wallet.`)
```

Customer kichu na kore e sobuj lekha dekhe: "35 minute late, ৳110 wallet e". Amader unique feature ta ekhane chokhe dekha jay. Order cholar shomoy o lekha thake: "We promised it by 7:14 PM".

Review form dekhano hoy shudhu `delivered` ar `!order.is_reviewed` hole. `is_reviewed` er jonno backend e choto ekta field jog kora hoyeche (`app/models/order.py`).

## 8. Vendor, Rider, Admin

Tin ta page ek e dhoron e lekha: `load()` function data ane ar page abar banay; button chaple API call, tarpor abar `load()`.

**Vendor:** `NEXT_STEPS` table theke button:

```js
const NEXT_STEPS = {
  placed: [["accepted", "Accept", "btn-primary"], ["rejected", "Reject", "btn-danger"]],
  accepted: [["ready", "Food is ready", "btn-primary"]],
};
```

Lesson 6 er `TRANSITIONS` er chhoto rup. Vendor er page o 8 second por por notun order ane.

**Rider:** hate ekta delivery thakle "Take this delivery" button bondho (backend o atkay, Lesson 7). Delivery card e boro kore lekha "Collect in cash: ৳635" (`amount_due`, wallet credit baad diye).

**Admin:** restaurant approve / batil, ar shob order er table, kar koto compensation.

## 9. Browser test

Amra ekta script diye ashol browser (Playwright) e puro golpo chaliyechi: customer login → cart → order → vendor accept → rider claim → ready → 35 minute late → delivered → customer er page e sobuj banner → review → wallet ৳110 → admin. Phone er mape (375 pixel) o check kora: page pash e shore na.

Eta repository te nai, karon er jonno Node.js lage. Tumi haate eki golpo ta koro (section 10).

## 10. Nije koro (puro golpo, 4 ta browser window)

Ek browser e 4 ta login ek shathe thake na (token ek ta). Tai: **ek ta normal window, ek ta Incognito/Private window**, ar dorkar hole arekta browser (Chrome + Edge).

1. Customer: Kacchi Ghor theke 2 ta biryani, cart e "Honest Price" dekho, order koro
2. Vendor (onno window): order ta 8 second er moddhe nije ashbe. Accept
3. Customer er window: kichu na chepe e "Cooking" e jay kina dekho
4. Rider: "Take this delivery". Vendor: "Food is ready"
5. Terminal: `python -m scripts.make_order_late 1 35`
6. Rider: "I picked up", "Delivered". Customer er page e sobuj banner
7. Review dao, wallet dekho, tarpor notun order e "Pay with wallet credit" tick dao

Code er exercise:

1. Polling 8 second theke 3 second koro (`orderPage` e). Ki labh, ki khoti?
2. Customer er order list e ekta "Reorder" button banao: oi order er item gula cart e dey. (Hint: `setQuantity` ar `order.items`.)
3. Rider page e aaj koyta delivery hoyeche dekhao (shudhu ajker tarikh).
4. Menu page e category gula upore "tab" hisebe dekhao, click korle oi jaygay jay. (Hint: `id` attribute ar `#` link... kintu amader router o `#` use kore! Ki shomossa hobe? `element.scrollIntoView()` diye koro.)
5. Viva proshno:
   - Hash router kivabe kaj kore?
   - Frontend e role check thakleo backend e keno?
   - Polling ki? WebSocket er shathe parthokko?
   - Frontend dam hishab kore na keno?
