// Restaurant owner pages: incoming orders, restaurants, menu.

import { api } from "../api.js";
import { busy, clock, dateTime, el, emptyState, field, formData, money, mount, pageTitle, statusChip, toast } from "../ui.js";

// What the restaurant can do next with an order in each status.
const NEXT_STEPS = {
  placed: [
    ["accepted", "Accept", "btn-primary"],
    ["rejected", "Reject", "btn-danger"],
  ],
  accepted: [["ready", "Food is ready", "btn-primary"]],
};

function orderCard(order, onChange) {
  const buttons = (NEXT_STEPS[order.status] || []).map(([status, label, style]) =>
    el(
      "button",
      {
        class: `btn ${style} btn-sm`,
        onclick: (event) =>
          (status !== "rejected" || confirm(`Reject order #${order.id}?`)) &&
          busy(event.currentTarget, async () => {
            await api(`/orders/${order.id}/status`, { method: "PATCH", body: { status } });
            onChange();
          }),
      },
      label,
    ),
  );
  return el(
    "div",
    { class: "card order-card" },
    el("div", { class: "row-between" }, el("strong", {}, `#${order.id} · ${order.restaurant.name}`), statusChip(order.status)),
    el("ul", { class: "lines compact" }, order.items.map((i) => el("li", {}, el("span", {}, `${i.quantity} × ${i.name}`)))),
    el(
      "div",
      { class: "row-between" },
      el("span", { class: "muted small" }, `Ordered ${clock(order.created_at)} · promised by ${clock(order.promised_at)}`),
      el("span", { class: "price" }, money(order.price.subtotal)),
    ),
    order.rider_id ? el("p", { class: "muted small" }, "A rider has taken this delivery.") : null,
    buttons.length ? el("div", { class: "actions" }, buttons) : null,
  );
}

function newRestaurantForm(onDone) {
  const submit = el("button", { class: "btn btn-primary", type: "submit" }, "Create restaurant");
  const form = el(
    "form",
    {
      class: "card form",
      onsubmit: (event) => {
        event.preventDefault();
        const data = formData(form);
        busy(submit, async () => {
          await api("/restaurants", {
            method: "POST",
            body: {
              name: data.name,
              address: data.address,
              description: data.description || null,
              avg_prep_minutes: Number(data.avg_prep_minutes),
            },
          });
          toast("Restaurant created. An admin must approve it before customers can see it.");
          onDone();
        });
      },
    },
    el("h2", { class: "h3" }, "Add a restaurant"),
    field("Name", el("input", { name: "name", required: true, minlength: 2, maxlength: 100 })),
    field("Address", el("input", { name: "address", required: true, minlength: 5, maxlength: 255 })),
    field("Short description", el("input", { name: "description", maxlength: 500 })),
    field("Usual cooking time (minutes)", el("input", { name: "avg_prep_minutes", type: "number", min: 5, max: 120, value: 20, required: true })),
    submit,
  );
  return form;
}

export async function vendorPage(params, ctx) {
  const ordersBox = el("div", { class: "stack" });
  const restaurantsBox = el("div", { class: "stack" });

  const loadOrders = async () => {
    const orders = await api("/orders?limit=50");
    const active = orders.filter((o) => ["placed", "accepted", "ready", "picked_up"].includes(o.status));
    const done = orders.filter((o) => !active.includes(o)).slice(0, 10);
    mount(
      ordersBox,
      active.length ? active.map((o) => orderCard(o, loadOrders)) : emptyState("No active orders. New ones show up here by themselves."),
      done.length
        ? el(
            "details",
            { class: "card" },
            el("summary", {}, `Recent finished orders (${done.length})`),
            el(
              "ul",
              { class: "lines" },
              done.map((o) =>
                el("li", {}, el("span", {}, `#${o.id} · ${dateTime(o.created_at)}`), el("span", { class: "line-end" }, statusChip(o.status), money(o.price.subtotal))),
              ),
            ),
          )
        : null,
    );
  };

  const loadRestaurants = async () => {
    const mine = await api("/restaurants/mine");
    mount(
      restaurantsBox,
      mine.map((r) =>
        el(
          "div",
          { class: "card row-between wrap" },
          el(
            "div",
            {},
            el("strong", {}, r.name),
            el(
              "div",
              { class: "rc-meta" },
              r.is_approved ? el("span", { class: "chip chip-good" }, "Approved") : el("span", { class: "chip chip-warn" }, "Waiting for admin"),
              r.is_open ? el("span", { class: "chip chip-good" }, "Open") : el("span", { class: "chip chip-bad" }, "Closed"),
              el("span", { class: "muted small" }, r.review_count ? `★ ${r.average_rating} (${r.review_count})` : "No reviews yet"),
            ),
          ),
          el(
            "div",
            { class: "actions" },
            el(
              "button",
              {
                class: "btn btn-ghost btn-sm",
                onclick: (event) =>
                  busy(event.currentTarget, async () => {
                    await api(`/restaurants/${r.id}`, { method: "PATCH", body: { is_open: !r.is_open } });
                    loadRestaurants();
                  }),
              },
              r.is_open ? "Close for now" : "Open",
            ),
            el("a", { class: "btn btn-primary btn-sm", href: `#/vendor/restaurant/${r.id}` }, "Edit menu"),
          ),
        ),
      ),
      newRestaurantForm(loadRestaurants),
    );
  };

  await Promise.all([loadOrders(), loadRestaurants()]);
  ctx.every(8000, () => loadOrders().catch(() => {}));

  return el(
    "div",
    {},
    pageTitle("Restaurant dashboard"),
    el("section", { class: "section" }, el("h2", { class: "h3" }, "Orders"), ordersBox),
    el("section", { class: "section" }, el("h2", { class: "h3" }, "Your restaurants"), restaurantsBox),
  );
}

// ---------- Menu editor ----------

function menuRow(item, onChange) {
  const price = el("input", { type: "number", min: 1, max: 100000, value: item.price, class: "price-input", "aria-label": `Price of ${item.name}` });
  const save = el("button", { class: "btn btn-ghost btn-sm" }, "Save price");
  save.addEventListener("click", () =>
    busy(save, async () => {
      await api(`/menu-items/${item.id}`, { method: "PATCH", body: { price: Number(price.value) } });
      toast(`${item.name}: ${money(price.value)}`);
      onChange();
    }),
  );
  return el(
    "li",
    { class: item.is_available ? "" : "off" },
    el("div", {}, el("div", {}, item.name), el("div", { class: "muted small" }, item.category)),
    el(
      "div",
      { class: "line-end wrap" },
      price,
      save,
      el(
        "button",
        {
          class: `btn btn-sm ${item.is_available ? "btn-ghost" : "btn-primary"}`,
          onclick: (event) =>
            busy(event.currentTarget, async () => {
              await api(`/menu-items/${item.id}`, { method: "PATCH", body: { is_available: !item.is_available } });
              onChange();
            }),
        },
        item.is_available ? "Mark sold out" : "Available again",
      ),
    ),
  );
}

export async function restaurantAdminPage([id], ctx) {
  const box = el("div", {});

  const load = async () => {
    const [restaurant, menu] = await Promise.all([api(`/restaurants/${id}`), api(`/restaurants/${id}/menu`)]);
    const submit = el("button", { class: "btn btn-primary", type: "submit" }, "Add item");
    const form = el(
      "form",
      {
        class: "card form",
        onsubmit: (event) => {
          event.preventDefault();
          const data = formData(form);
          busy(submit, async () => {
            await api(`/restaurants/${id}/menu-items`, {
              method: "POST",
              body: { name: data.name, category: data.category, price: Number(data.price), description: data.description || null },
            });
            toast(`${data.name} added`);
            load();
          });
        },
      },
      el("h2", { class: "h3" }, "Add a menu item"),
      field("Name", el("input", { name: "name", required: true, minlength: 2, maxlength: 100 })),
      field("Category", el("input", { name: "category", required: true, minlength: 2, maxlength: 50, placeholder: "Biryani, Drinks, …" })),
      field("Price (whole taka)", el("input", { name: "price", type: "number", min: 1, max: 100000, required: true })),
      field("Description", el("input", { name: "description", maxlength: 500 })),
      submit,
    );
    mount(
      box,
      el("a", { class: "back", href: "#/vendor" }, "← Dashboard"),
      pageTitle(restaurant.name, restaurant.is_approved ? "Approved" : "Waiting for admin approval"),
      el(
        "div",
        { class: "two-col" },
        el("div", { class: "card" }, menu.length ? el("ul", { class: "lines" }, menu.map((item) => menuRow(item, load))) : emptyState("No items yet.")),
        form,
      ),
    );
  };

  await load();
  return box;
}
